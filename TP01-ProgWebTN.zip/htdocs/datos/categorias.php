<?php $categorias=array(
							1 => array('id'=>8,'imagen' => 'product01.png','nombre' => 'Laptops', 'web'=>'laptops.php'),
							2 => array('id'=>9,'imagen' => 'product02.png','nombre' => 'Accesorios','web'=>'accesorios.php'),
							3 => array('id'=>10,'imagen' => 'product04.png','nombre' => 'Tablets','web'=>'tablets.php'),
							4 => array('id'=>11,'imagen' => 'product07.png','nombre' => 'Smartphones','web'=>'smartphones.php'),							
                            5 => array('id'=>12,'imagen' => 'product09.png','nombre' => 'Camaras','web'=>'camaras.php')
                           
);
							/*
							$var=json_encode($categorias);
							echo $var.'<br/ >';
				   
						  $datos=json_decode($var,true);
						  echo '<pre>';
						  var_dump($datos);
						  echo '</pre>';
     */
	$json = json_encode($categorias);
	$file = 'categorias.json'; 
	file_put_contents($file, $json);


							?>
<?php $ofertas=array(
        1=>array('imagen' =>'shop01.png','nombre'=>'nombre1'),
        2=>array('imagen' =>'shop02.png','nombre'=>'nombre2'),
        3=>array('imagen' =>'shop03.png','nombre'=>'nombre3'),
       );    ?>
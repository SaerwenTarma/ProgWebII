<?php $productos=array(
							1 => array('imagen' => 'product01.png','categorias' => 8,'marca' => 26,'nombre' => 'nombre1','precio' => '980.000','precio_anterior' => '105.000', 'descuento' =>'-30%', 'activo'=> true, 'nuevo' => true,'descuento' =>'-30%'),
							2 => array('imagen' => 'product02.png','categorias' => 9,'marca' => 20,'nombre' => 'nombre2','precio' => '60.000','precio_anterior' => '75.000.000','descuento'=>'-10%','activo'=> true,'nuevo' => true),
							3 => array('imagen' => 'product03.png','categorias' => 8,'marca' => 26,'nombre' => 'nombre3','precio' => '44.000','precio_anterior' => '50.000','descuento'=>'-50%','activo'=> false,'nuevo' => true,'descuento' =>'-40%'),
							4 => array('imagen' => 'product04.png','categorias' => 10,'marca' =>21,'nombre' => 'nombre4','precio' => '20.000','precio_anterior' => '450.000','descuento'=>'-5%','activo'=> true,'nuevo' => false),
							5 => array('imagen' => 'product05.png','categorias' => 9,'marca' => 21 ,'nombre' => 'nombre5','precio' => '80.000','precio_anterior' => '89.000','descuento'=>'-25%','activo'=> false,'nuevo' => true),
							6 => array('imagen' => 'product06.png','categorias' => 8,'marca' => 25 ,'nombre' => 'nombre6','precio' => '34.000','precio_anterior' => '89.000','descuento'=>'-25%','activo'=> true,'nuevo' => false),
							7 => array('imagen' => 'product07.png','categorias' => 11,'marca' => 22,'nombre' => 'nombre7','precio' => '16.000','precio_anterior' => '89.000','descuento'=>'-25%','activo'=> true,'nuevo' => true),
							8 => array('imagen' => 'product08.png','categorias' => 8,'marca' =>  19,'nombre' => 'nombre8','precio' => '22.000','precio_anterior' => '89.000','descuento'=>'-25%','activo'=> true,'nuevo' => false),							
							9 => array('imagen' => 'product09.png','categorias' => 12,'marca' => 27,'nombre' => 'nombre9','precio' => '87.000','precio_anterior' => '89.000','descuento'=>'-25%','activo'=> true,'nuevo' => true),
							10 => array('imagen' => 'product10.png','categorias' => 11,'marca' => 22,'nombre' => 'nombre10','precio' => '88.000','precio_anterior' => '89.000','descuento'=>'-25%','activo'=> true,'nuevo' => false)
                        );
                          
  /*
                             $var=json_encode($productos);
                                 echo $var.'<br/ >';
								 					
							   $datos=json_decode($var,true);
							   echo '<pre>';
							   var_dump($datos);
							   echo '</pre>';
							
  */

  $json = json_encode($productos);
  $file = 'productos.json'; 
  file_put_contents($file, $json);

							?>
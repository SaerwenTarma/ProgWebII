<?php $marcas=array(
							1 => array('id' => 19,'nombre' => 'Asus'),
							2 => array('id' => 20,'nombre' => 'Philips'),
							3 => array('id' => 21,'nombre' => 'Sony'),
							4 => array('id' => 22,'nombre' => 'Samsung'),									
                            5 => array('id' => 24,'nombre' => 'Dell'),
                            6 => array('id' => 25,'nombre' => 'MSI'),
							7 => array('id' => 26,'nombre' => 'HP'),
							8 => array('id' => 27,'nombre' => 'Rekam')
);

                       /*
							$var=json_encode($marcas);
							echo $var.'<br/ >';
				   
						  $datos=json_decode($var,true);
						  echo '<pre>';
						  var_dump($datos);
						  echo '</pre>';
					   */
					  $json = json_encode($marcas);
					  $file = 'marcas.json'; 
					  file_put_contents($file, $json);









							?>


<!-- SECTION -->
<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
              
					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">Categorias</h3>
							<!-- SECCION DATOS  CATEGORIAS -->
							<?php  include('datos/categorias.php');  ?>

                             <!--     --------------------------------------->

                               <!--- NAVEGADOR CATEGORIAS -->
							<div class="section-nav">
								<ul class="section-tab-nav tab-nav">
								    <?php  foreach($categorias as $cat){    ?>
									<li class="<?php echo ($seccion==['nombre'])?'active':'';?>"><a  href=  "categorias.php?cat=<?php echo $cat['id'] ?>" ><?php echo $cat ['nombre'] ?></a></li>
									<?php } ?>
								</ul>
							</div>
						</div>
					</div>
					<!-- /section title -->
				

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab1" class="tab-pane active">
									<div class="products-slick" data-nav="#slick-nav-1">


										<!-- SLIDE DE PRODUCTOS -->
										<?php foreach($categorias as $cat){ 
											?>
									
                                        
										<div class="product">
											<div class="product-img">
											
												<img src="./img/<?php echo $cat['imagen']; ?>" alt="">
												
											</div>
											
											<div class="product-body">
										
												
												
												<h3 class="product-name"><a href="index.php?cat=<?php echo $cat['id'];?>"><?php echo $cat ['nombre']; ?> </a></h3>
												
												
												
											</div>
											
										</div> 
									
										<?php  } ?>

								
                                      <!-- FIN DE SLIDE DE PRODUCTOS -->




										

										

										
									</div>
									<div id="slick-nav-1" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->


					
					
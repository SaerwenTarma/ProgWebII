
	 	<!-- SECTION -->
<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
              
					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">Productos</h3>

							<!-- SECCION DATOS  productos -->  
					           <?PHP  include('datos/productos.php');?>
							   <?php  include('datos/categorias.php');  ?>
                              
                              <!--            ------------------------------------------------->


							              <!--- NAVEGADOR CATEGORIAS -->
										  <div class="section-nav">
								<ul class="section-tab-nav tab-nav">
								    <?php  foreach($categorias as $cat){    ?>
									<li class="<?php echo ($seccion==['nombre'])?'active':'';?>"><a  href=  "index.php?cat=<?php echo $cat['id'] ?>" ><?php echo $cat ['nombre'] ?></a></li>
									<?php } ?>
								</ul>
							</div>
						</div>
					</div>
					<!-- /section title -->
				

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab1" class="tab-pane active">
									<div class="products-slick" data-nav="#slick-nav-1">


										<!-- SLIDE DE PRODUCTOS -->
										<?php foreach($productos as $prod){ 
										if($prod['activo']==true){
                                                  $imprimir=true;
											// if(isset($_GET['cat'])&& $_GET['cat'] !=''(                    
											if(!empty($_GET['cat'])) {   //si no esta vacio el cat= y existe osea dice cat= ej: index.php?cat= 
                                                      if($prod ['categorias']!= $_GET['cat']) {
													   $imprimir=false;
												}
											}  
											if(!empty($_GET['marca'])) {   //si no esta vacio el marca= y existe osea dice marca= ej: index.php?marca= 
                                                      if($prod ['marca']!= $_GET['marca']) {
													   $imprimir=false;
												}
									        }  
											    if($imprimir){	
											
																	?>
															
																
																<div class="product">
																	<div class="product-img">
																	
																		<img src="./img/<?php echo $prod['imagen']; ?>" alt="">
																	<?php  if($prod['nuevo']==true){              ?>
																		<div class="product-label">
																		<span class="sale">Nuevo</span>
																		<?php if($prod['descuento']==true) { ?>          
																		<span class="new"> <?php echo $prod ['descuento'];  ?> </span>  <?php } ?>



																	</div>  <?php } ?>
																	</div>
																	
																	<div class="product-body">
																
																	<!--	<p class="product-category"><?php echo $prod ['categorias']; ?></p> -->
																		
																		<h3 class="product-name"><a href="#"><?php echo $prod ['nombre']; ?> </a></h3>
																		<h4 class="product-price"><?php echo $prod['precio']; ?> <del class="product-old-price"><?php echo $prod ['precio_anterior'] ?></del></h4>
																		<div class="product-rating">
																			<i class="fa fa-star"></i>
																			<i class="fa fa-star"></i>
																			<i class="fa fa-star"></i>
																			<i class="fa fa-star"></i>
																			<i class="fa fa-star"></i>
																		</div>
																		<div class="product-btns">
																			<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">Favoritos</span></button>
																			<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">Comparar</span></button>
																			<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">Vista Rapida</span></button>
																		</div>
																	</div>
																	<div class="add-to-cart">
																		<button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> AGREGAR</button>
																	</div>
																</div> 
									        
											<?php  }}}
                                                      
                                                     
											
											
										
									 ?>

								
                                      <!-- FIN DE SLIDE DE PRODUCTOS -->




										

										

										
									</div>
									<div id="slick-nav-1" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->


					
					
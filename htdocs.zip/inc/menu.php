<!-- Menu Toogle -->
<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="<?php echo ($seccion=='index')?'active':''?>"><a href="index.php">Inicio</a></li>
						
						<li  class="<?php echo ($seccion=='laptops')?'active':''?>"  ><a href="#">Quienes somos</a></li>
						<li  class="<?php echo ($seccion=='smartphones')?'active':''?>"  ><a href="#">Contacto</a></li>
						<li  class="<?php echo ($seccion=='camaras')?'active':''?>"  ><a href="#">Nuestor clientes</a></li>
						<li  class="<?php echo ($seccion=='abm')?'active':''?>"  ><a href="admin/abm.php">ABM</a></li>
						
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

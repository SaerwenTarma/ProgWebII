
<?php

$datoprod=	file_get_contents('productos.json');
$datosJsonp=json_decode($datoprod,true);
if(isset($_GET['id'])){

echo 'algo'

};

    ?>